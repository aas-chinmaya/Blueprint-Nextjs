"use client";



export default function page() {
 

  return (
    <>
  
      Quotation 
    </>
  );
}
