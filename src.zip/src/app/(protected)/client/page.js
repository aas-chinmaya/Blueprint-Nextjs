"use client";
import AllClientList from "@/components/clients/AllClientList";

export default function Page() {
  return (
    <>
      <div className="px-4 lg:px-6">
        <AllClientList />
      </div>
    </>
  );
}
