'use client';

import AddClient from '@/components/clients/ClientOnboarding';
import React from 'react';

export default function ClientOnboarding() {
  return (
       <>
          <div className="px-4 lg:px-6">
          
          <AddClient />
          </div>
        </>
     
      
  );
}