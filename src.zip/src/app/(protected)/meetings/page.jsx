import Meeting from "@/components/meetings/Meeting";

// this file should be de;leted later after testing the meeting  
export default function Page() {
  return (
    <>
      <div className="px-4 lg:px-6">
     <Meeting/>
    
      </div>
    </>
  );
}