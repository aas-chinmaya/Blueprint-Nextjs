import SlotMaster from "@/components/masters/SlotMaster";


export default function Page() {
  return (
    <>
      <div className="px-4 lg:px-6">

<SlotMaster/>
      </div>
    </>
  );
}