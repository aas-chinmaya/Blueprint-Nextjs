export default function UnauthorizedPage() {
  return <h1>403 - You are not authorized to view this page.</h1>;
}
